#-*- coding: utf-8 -*-

from django.http import HttpResponse


def home(request):
    return render(request, 'templates/index.html')

from django.shortcuts import render
from django import template



# Create your views here.
