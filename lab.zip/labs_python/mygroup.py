groupmates = [
 {
 "name": "Антон",
 "surname": "Лопсиков",
 "exams": ["Электрика", "Сантехника", "Готовка"],
 "marks": [2, 2, 2]
 },
 {
 "name": "Владимир",
 "surname": "Солнцев",
 "exams": ["Математика", "Черчение", "Отдых"],
 "marks": [5, 5, 5]
 },
 {
 "name": "Бобер",
 "surname": "Выдров",
 "exams": ["Плаванье", "Работа по дереву", "Отдых"],
 "marks": [4, 4, 5]
 },
 {
 "name": "Василина",
 "surname": "Василиск",
 "exams": ["Гимнастика", "Программирование", "Выжигание"],
 "marks": [6, 6, 6]
 }
]
def count_mark(students,mark):
    print ("surname".ljust(15), "marks".ljust(20))
    for student in students:
        marks_list = student["marks"]
        result = (sum(marks_list)/len(marks_list))
        if result >= need:
            print(student["surname"].ljust(15), str(student["marks"]).ljust(20))

need = int(input('Input :'))

count_mark(groupmates,need)
